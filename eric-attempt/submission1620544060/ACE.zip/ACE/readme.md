Simply install the requirements in requirements.txt (just transformers and pytorch) and run:
python test_submission.py [path_to_eval.jsonl]

